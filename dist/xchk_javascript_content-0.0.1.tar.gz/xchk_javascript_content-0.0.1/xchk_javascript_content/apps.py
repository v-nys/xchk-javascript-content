from django.apps import AppConfig


class JavascriptcontentConfig(AppConfig):
    name = 'xchk_javascript_content'
